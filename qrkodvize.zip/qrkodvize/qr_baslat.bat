@echo off
echo ===================================================
echo 🔍  QR Kod Okuyucu Uygulamasi Baslatiliyor...
echo ===================================================
echo.

py --version >nul 2>&1
if errorlevel 1 (
    echo [HATA] Bilgisayarinizda Python kurulu degil veya komut satirindan erisilemiyor.
    echo Lutfen Python'u indirip kurun ve "Add Python to PATH" secenegini isaretlediginizden emin olun.
    pause
    exit /b
)

echo [1/2] Paket yoneticisi (pip) kontrol ediliyor ve guncelleniyor...
py -m pip install --upgrade pip >nul 2>&1

echo [2/2] QR Kod algilama ve arayuz icin gerekli kutuphaneler kuruluyor...
echo (Bilgisayarinizda kurulu degilse internetten indirilip kurulacaktir)
py -m pip install PyQt5 opencv-python numpy
echo.
echo === Kurulum Basarili! ===

echo Uygulama aciliyor, lutfen bekleyin...
py qr_kod_okuyucu.py

if errorlevel 1 (
    echo.
    echo [HATA] Beklenmeyen bir problem olustu. Hata kodunu yukaridan inceleyebilirsiniz.
    pause
)
