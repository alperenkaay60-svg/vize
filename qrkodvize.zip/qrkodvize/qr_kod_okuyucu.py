import sys
import cv2
import numpy as np

from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QListWidget, QFrame, QSizePolicy, QListWidgetItem
)
from PyQt5.QtCore import Qt, QTimer, QRectF
from PyQt5.QtGui import (
    QImage, QPixmap, QColor, QPainter, QPainterPath, QPen
)

KOYU_ARKAPLAN = "#0f0f14"
ANA_ARKAPLAN = "#16161e"
IKINCIL_ARKAPLAN = "#1c1c27"
UCUNCUL_ARKAPLAN = "#22222f"
KART_ARKAPLAN = "#1a1a25"
YUKSELTI_ARKAPLAN = "#252535"

INCE_KENAR = "#2a2a3a"
NORMAL_KENAR = "#33334a"
AKTIF_KENAR = "#4a4a6a"

ANA_YAZI = "#e8e8f0"
IKINCIL_YAZI = "#9898b0"
SOLUK_YAZI = "#606078"

MOR_VURGU = "#7c6fea"
YESIL = "#5cb88a"
KIRMIZI = "#e06070"
MAVI = "#5a8fd8"

def rengi_acikla(hex_renk, miktar):
    c = QColor(hex_renk)
    h, s, l, a = c.getHslF()
    c.setHslF(h, s, min(1.0, l + miktar / 100), a)
    return c.name()

def rengi_koyulastir(hex_renk, miktar):
    c = QColor(hex_renk)
    h, s, l, a = c.getHslF()
    c.setHslF(h, s, max(0.0, l - miktar / 100), a)
    return c.name()

def buton_stili_olustur(renk):
    return f"""
        QPushButton {{
            background-color: {renk};
            color: #ffffff;
            border: none;
            border-radius: 8px;
            padding: 10px 15px;
            font-size: 13px;
            font-weight: bold;
        }}
        QPushButton:hover {{
            background-color: {rengi_acikla(renk, 15)};
        }}
        QPushButton:pressed {{
            background-color: {rengi_koyulastir(renk, 10)};
        }}
        QPushButton:disabled {{
            background-color: {UCUNCUL_ARKAPLAN};
            color: {SOLUK_YAZI};
        }}
    """

class KameraPaneli(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.piksel_haritasi = None
        self.setMinimumSize(640, 480)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        
    def goruntu_ayarla(self, cv_goruntu):
        if cv_goruntu is None:
            self.piksel_haritasi = None
            self.update()
            return
            
        yukseklik, genislik = cv_goruntu.shape[:2]
        if len(cv_goruntu.shape) == 2:
            q_img = QImage(cv_goruntu.data, genislik, yukseklik, genislik, QImage.Format_Grayscale8)
        else:
            rgb = cv2.cvtColor(cv_goruntu, cv2.COLOR_BGR2RGB)
            q_img = QImage(rgb.data, genislik, yukseklik, 3 * genislik, QImage.Format_RGB888)
            
        self.piksel_haritasi = QPixmap.fromImage(q_img)
        self.update()
        
    def paintEvent(self, event):
        cizici = QPainter(self)
        cizici.setRenderHint(QPainter.Antialiasing)
        cizici.setRenderHint(QPainter.SmoothPixmapTransform)
        alan = QRectF(self.rect())
        
        yol = QPainterPath()
        yol.addRoundedRect(alan.adjusted(0.5, 0.5, -0.5, -0.5), 12, 12)
        cizici.fillPath(yol, QColor(KOYU_ARKAPLAN))
        cizici.setPen(QPen(QColor(INCE_KENAR), 1))
        cizici.drawPath(yol)
        
        if self.piksel_haritasi:
            bosluk = 4
            goruntu_alani = alan.adjusted(bosluk, bosluk, -bosluk, -bosluk)
            
            olcekli = self.piksel_haritasi.scaled(
                int(goruntu_alani.width()), int(goruntu_alani.height()),
                Qt.KeepAspectRatio, Qt.SmoothTransformation
            )
            
            x = goruntu_alani.x() + (goruntu_alani.width() - olcekli.width()) / 2
            y = goruntu_alani.y() + (goruntu_alani.height() - olcekli.height()) / 2
            
            kirpma = QPainterPath()
            kirpma.addRoundedRect(QRectF(x, y, olcekli.width(), olcekli.height()), 8, 8)
            cizici.setClipPath(kirpma)
            cizici.drawPixmap(int(x), int(y), olcekli)
            cizici.setClipping(False)
        else:
            cizici.setPen(QPen(QColor(SOLUK_YAZI), 1))
            cizici.drawText(alan, Qt.AlignCenter, "Kamera Kapali\nLutfen Baslat butonuna tiklayin.")
            
        cizici.end()

class QRKodOkuyucuApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("QR Kod Okuyucu")
        self.setMinimumSize(950, 650)
        
        self.kamera = None
        self.kamera_acik = False
        self.zamanlayici = QTimer()
        self.zamanlayici.timeout.connect(self.kare_yakala)
        self.qr_detector = cv2.QRCodeDetector()
        
        self.okunan_qrs = set()
        
        self._stilleri_uygula()
        self._arayuzu_kur()
        
    def _stilleri_uygula(self):
        self.setStyleSheet(f"""
            QMainWindow {{ background: {ANA_ARKAPLAN}; }}
            QWidget {{ background: transparent; color: {ANA_YAZI}; font-family: 'Segoe UI', sans-serif; font-size: 13px; }}
            QListWidget {{
                background: {KOYU_ARKAPLAN};
                color: {ANA_YAZI};
                border: 1px solid {INCE_KENAR};
                border-radius: 8px;
                padding: 6px;
                font-size: 13px;
                outline: none;
            }}
            QListWidget::item {{
                padding: 10px;
                border-bottom: 1px solid {INCE_KENAR};
            }}
            QListWidget::item:selected {{
                background: {YUKSELTI_ARKAPLAN};
                border-radius: 4px;
            }}
            QScrollBar:vertical {{
                background: transparent; width: 8px; margin: 2px;
            }}
            QScrollBar::handle:vertical {{
                background: {NORMAL_KENAR}; border-radius: 4px; min-height: 20px;
            }}
            QScrollBar::handle:vertical:hover {{ background: {AKTIF_KENAR}; }}
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0; }}
        """)
        
    def _arayuzu_kur(self):
        merkez = QWidget()
        self.setCentralWidget(merkez)
        
        ana_duzen = QHBoxLayout(merkez)
        ana_duzen.setContentsMargins(20, 20, 20, 20)
        ana_duzen.setSpacing(15)
        
        sol_panel = QWidget()
        sol_panel.setFixedWidth(300)
        sol_duzen = QVBoxLayout(sol_panel)
        sol_duzen.setContentsMargins(0, 0, 0, 0)
        sol_duzen.setSpacing(15)
        
        baslik_etiketi = QLabel("QR KOD OKUYUCU")
        baslik_etiketi.setStyleSheet(f"font-size: 18px; font-weight: 800; color: {MOR_VURGU}; letter-spacing: 1px;")
        sol_duzen.addWidget(baslik_etiketi)
        
        kontrol_paneli = QFrame()
        kontrol_paneli.setStyleSheet(f"QFrame {{ background: {IKINCIL_ARKAPLAN}; border-radius: 12px; border: 1px solid {INCE_KENAR}; }}")
        kontrol_duzen = QVBoxLayout(kontrol_paneli)
        kontrol_duzen.setContentsMargins(15, 15, 15, 15)
        kontrol_duzen.setSpacing(10)
        
        kamera_baslik = QLabel("KAMERA KONTROLU")
        kamera_baslik.setStyleSheet(f"color: {SOLUK_YAZI}; font-size: 11px; font-weight: 800; letter-spacing: 0.5px;")
        kontrol_duzen.addWidget(kamera_baslik)
        
        self.btn_baslat = QPushButton("▶  Baslat")
        self.btn_baslat.setCursor(Qt.PointingHandCursor)
        self.btn_baslat.setStyleSheet(buton_stili_olustur(YESIL))
        self.btn_baslat.clicked.connect(self.kamerayi_baslat)
        kontrol_duzen.addWidget(self.btn_baslat)
        
        self.btn_durdur = QPushButton("■  Durdur")
        self.btn_durdur.setCursor(Qt.PointingHandCursor)
        self.btn_durdur.setStyleSheet(buton_stili_olustur(KIRMIZI))
        self.btn_durdur.setEnabled(False)
        self.btn_durdur.clicked.connect(self.kamerayi_durdur)
        kontrol_duzen.addWidget(self.btn_durdur)
        
        sol_duzen.addWidget(kontrol_paneli)
        
        gecmis_baslik = QLabel("OKUNAN KOD GECMISI")
        gecmis_baslik.setStyleSheet(f"color: {SOLUK_YAZI}; font-size: 11px; font-weight: 800; margin-top: 10px; letter-spacing: 0.5px;")
        sol_duzen.addWidget(gecmis_baslik)
        
        self.liste_qrs = QListWidget()
        sol_duzen.addWidget(self.liste_qrs)
        
        temizle_btn = QPushButton("🗑  Gecmisi Temizle")
        temizle_btn.setFixedHeight(35)
        temizle_btn.setCursor(Qt.PointingHandCursor)
        temizle_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {YUKSELTI_ARKAPLAN};
                color: {IKINCIL_YAZI};
                border: 1px solid {INCE_KENAR};
                border-radius: 8px; font-size: 12px; font-weight: bold;
            }}
            QPushButton:hover {{ background-color: {UCUNCUL_ARKAPLAN}; color: {ANA_YAZI}; border-color: {NORMAL_KENAR}; }}
        """)
        temizle_btn.clicked.connect(self.gecmisi_temizle)
        sol_duzen.addWidget(temizle_btn)
        
        ana_duzen.addWidget(sol_panel)
        
        sag_panel = QVBoxLayout()
        sag_panel.setContentsMargins(5, 0, 0, 0)
        sag_panel.setSpacing(10)
        
        ust_bilgi = QLabel("Canli Kamera Akisi")
        ust_bilgi.setStyleSheet(f"color: {IKINCIL_YAZI}; font-size: 14px; font-weight: bold;")
        sag_panel.addWidget(ust_bilgi)
        
        self.kamera_paneli = KameraPaneli()
        sag_panel.addWidget(self.kamera_paneli, 1)
        
        self.sonuc_etiketi = QLabel("Lutfen kamerayi baslatin.")
        self.sonuc_etiketi.setAlignment(Qt.AlignCenter)
        self.sonuc_etiketi.setStyleSheet(f"""
            QLabel {{
                background: {YUKSELTI_ARKAPLAN};
                color: {SOLUK_YAZI};
                border: 2px dashed {NORMAL_KENAR};
                border-radius: 12px;
                padding: 15px;
                font-size: 14px;
                font-weight: bold;
            }}
        """)
        sag_panel.addWidget(self.sonuc_etiketi)
        
        ana_duzen.addLayout(sag_panel, 1)
        
    def kamerayi_baslat(self):
        if not self.kamera_acik:
            self.kamera = cv2.VideoCapture(0)
            if not self.kamera.isOpened():
                self.sonuc_etiketi.setText("Kamera acilamadi! Gerekli donanim erisim izni oldugundan emin olun.")
                self.sonuc_etiketi.setStyleSheet(f"color: {KIRMIZI}; border: 2px dashed {KIRMIZI}; padding: 15px; background: {IKINCIL_ARKAPLAN};")
                return
                
            self.kamera_acik = True
            
            self.btn_baslat.setEnabled(False)
            self.btn_durdur.setEnabled(True)
            
            self.sonuc_etiketi.setText("Zamanli Izleme Aktif. Kameraya QR Kod Gosterin...")
            self.sonuc_etiketi.setStyleSheet(f"color: {MAVI}; border: 2px dotted {MAVI}; padding: 15px; background: {IKINCIL_ARKAPLAN};")
            
            self.zamanlayici.start(33) 
            
    def kamerayi_durdur(self):
        if self.kamera_acik:
            self.zamanlayici.stop()
            if self.kamera:
                self.kamera.release()
            self.kamera_acik = False
            
            self.btn_baslat.setEnabled(True)
            self.btn_durdur.setEnabled(False)
            self.kamera_paneli.goruntu_ayarla(None)
            
            self.sonuc_etiketi.setText("Kamera Durduruldu.")
            self.sonuc_etiketi.setStyleSheet(f"color: {SOLUK_YAZI}; border: 2px dashed {NORMAL_KENAR}; padding: 15px; background: {YUKSELTI_ARKAPLAN};")
            
    def gecmisi_temizle(self):
        self.liste_qrs.clear()
        self.okunan_qrs.clear()
        
    def kare_yakala(self):
        if not self.kamera_acik or not self.kamera:
            return
            
        basarili_mi, frame = self.kamera.read()
        if not basarili_mi:
            return
            
        veriler, kutu_puanlari, _ = self.qr_detector.detectAndDecode(frame)
        
        if veriler and kutu_puanlari is not None:
            
            kutu = kutu_puanlari[0].astype(int)
            nokta_sayisi = len(kutu)
            
            for i in range(nokta_sayisi):
                baslangic = tuple(kutu[i])
                bitis = tuple(kutu[(i + 1) % nokta_sayisi])
                
                cv2.line(frame, baslangic, bitis, (255, 150, 0), 3) 
                
            cv2.putText(frame, veriler, (kutu[0][0], kutu[0][1] - 15), 
                        cv2.FONT_HERSHEY_DUPLEX, 0.6, (0, 255, 0), 2)
            
            self.sonuc_etiketi.setText(f"✓ Basarili: {veriler}")
            self.sonuc_etiketi.setStyleSheet(f"""
                QLabel {{ color: {KOYU_ARKAPLAN}; background: {YESIL};
                border: 2px solid {YESIL}; border-radius: 12px; padding: 15px; font-weight: bold; font-size: 15px; }}
            """)
            
            if veriler not in self.okunan_qrs:
                self.okunan_qrs.add(veriler)
                
                item = QListWidgetItem(f"🔑 {veriler}")
                item.setToolTip(veriler)
                self.liste_qrs.insertItem(0, item)
            
        self.kamera_paneli.goruntu_ayarla(frame)

    def closeEvent(self, event):
        self.kamerayi_durdur()
        event.accept()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    pencere = QRKodOkuyucuApp()
    pencere.show()
    sys.exit(app.exec_())
